import  { useState, useEffect } from "react";

const FeedScheduleForm = () => {
  const [livestockGroupId, setLivestockGroupId] = useState("");
  const [feedId, setFeedId] = useState("");
  const [quantity, setQuantity] = useState("");
  const [approvedQuantity, setApprovedQuantity] = useState("");
  const [approver, setApprover] = useState("");
  const [feedLocation, setFeedLocation] = useState("");
  const [frequency, setFrequency] = useState("");
  const [timeOfDay, setTimeOfDay] = useState("");
  const [occurence, setOccurence] = useState("");
  const [message, setMessage] = useState("");

  const [feeds, setFeeds] = useState([]);
  const [livestockGroups, setLivestockGroups] = useState([]);

  // Fetch feeds and livestock groups when component mounts
  useEffect(() => {
    const fetchData = async () => {
      try {
        const feedsResponse = await fetch("/api/feed-types");
        if (!feedsResponse.ok) throw new Error("Failed to fetch feeds");
        const feedsData = await feedsResponse.json();
        setFeeds(feedsData);
        console.log(feedsData)

        const livestockGroupsResponse = await fetch("/api/livestock-groups");
        if (!livestockGroupsResponse.ok) throw new Error("Failed to fetch livestock groups");
        const livestockGroupsData = await livestockGroupsResponse.json();
        setLivestockGroups(livestockGroupsData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("/api/feed-schedules", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          livestock_group_id: livestockGroupId,
          feed_id: feedId,
          quantity,
          approved_quantity: approvedQuantity,
          approver,
          feed_location: feedLocation,
          frequency,
          time_of_day: timeOfDay,
          occurence,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        console.log(data);
        
        setMessage("Feed schedule created successfully!");
        // Reset form fields
        resetForm();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.errors ? errorData.errors : "Error creating feed schedule.");
      }
    } catch (error) {
      console.error("Error creating feed schedule:", error);
      setMessage("Error creating feed schedule.");
    }
  };

  // Reset form fields after successful submission
  const resetForm = () => {
    setLivestockGroupId("");
    setFeedId("");
    setQuantity("");
    setApprovedQuantity("");
    setApprover("");
    setFeedLocation("");
    setFrequency("");
    setTimeOfDay("");
    setOccurence("");
  };

  return (
    <div>
      <h2>Create Feed Schedule</h2>
      <form onSubmit={handleSubmit}>
        
        <div>
          <label>Livestock Group:</label>
          <select value={livestockGroupId} onChange={(e) => setLivestockGroupId(e.target.value)} required>
            <option value="">Select Livestock Group</option>
            {livestockGroups.map((group) => (
              <option key={group.id} value={group.id}>
                {group.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label>Feed:</label>
          <select value={feedId} onChange={(e) => setFeedId(e.target.value)} required>
            <option value="">Select Feed</option>
            {feeds.map((feed) => (
              <option key={feed.id} value={feed.id}>
                {feed.feed_name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label>Quantity:</label>
          <input type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} required />
        </div>

        <div>
          <label>Approved Quantity:</label>
          <input type="number" value={approvedQuantity} onChange={(e) => setApprovedQuantity(e.target.value)} />
        </div>

        <div>
          <label>Approver:</label>
          <input type="text" value={approver} onChange={(e) => setApprover(e.target.value)} />
        </div>

        <div>
          <label>Feed Location:</label>
          <input type="text" value={feedLocation} onChange={(e) => setFeedLocation(e.target.value)} />
        </div>

        <div>
          <label>Frequency:</label>
          <input type="text" value={frequency} onChange={(e) => setFrequency(e.target.value)} required />
        </div>

        <div>
          <label>Time of Day:</label>
          <input type="text" value={timeOfDay} onChange={(e) => setTimeOfDay(e.target.value)} required />
        </div>

        <div>
          <label>Occurence:</label>
          <input type="text" value={occurence} onChange={(e) => setOccurence(e.target.value)} required />
        </div>

        <button type="submit">Create Feed Schedule</button>

      </form>

      {message && <p>{message}</p>}
    </div>
  );
};

export default FeedScheduleForm;