
export const FeedTypeFormList = () => {
  return (
    <div>FeedTypeFormList</div>
  )
}
